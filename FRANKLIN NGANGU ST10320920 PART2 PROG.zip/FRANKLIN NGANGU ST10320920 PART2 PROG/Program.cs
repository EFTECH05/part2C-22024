﻿
using System;
using System.Collections.Generic;



namespace POE_4
{
    // Delegate declaration for calculating total calories
    public delegate void CalorieCalculationDelegate(int[] calorieArray);

    // Main class
    internal class Program
    {
        // Declaring class-level variables and collections
        Queue<string> IngredientNames = new Queue<string>(); // Queue to store ingredient names
        Queue<string> Descriptions = new Queue<string>(); // Queue to store descriptions
        Queue<float> Quantities = new Queue<float>(); // Queue to store quantities
        Queue<float> MeasurementUnits = new Queue<float>(); // Queue to store measurement units
        Queue<int> Steps = new Queue<int>(); // Queue to store steps
        Queue<string> RecipeNames = new Queue<string>(); // Queue to store recipe names
        Queue<int> NumberOfIngredients = new Queue<int>(); // Queue to store number of ingredients
        int NumberOfRecipes; // Variable to store number of recipes
        int[] CaloriesPerIngredient = new int[20]; // Array to store calories per ingredient
        string[] FoodGroups = new string[20]; // Array to store food groups
        int[] ConvertedSteps = new int[10]; // Array to store converted steps
        float[] ConvertedQuantities = new float[20]; // Array to store converted quantities
        float[] ConvertedQuantities1 = new float[20]; // Array to store converted quantities
        string PlaceCondition; // Variable to store place condition
        string PlaceConditionConvert; // Variable to store converted place condition
        string Condition2; // Variable to store condition 2
        string[] ConvertedDescriptions = new string[20]; // Array to store converted descriptions
        string Condition3; // Variable to store condition 3
        string Option; // Variable to store user option
        string IndexFromList; // Variable to store index from list
        string Option2; // Variable to store option 2
        int NumberOfIngredientsInput; // Variable to store number of ingredients input
        Queue<int> ContainCalories = new Queue<int>(); // Queue to store whether calories are contained
        int CalorieCount; // Variable to store calorie count
        Queue<string> FoodGroupsInput = new Queue<string>(); // Queue to store food groups input
        float[] ConvertedQuantitiesY = new float[20]; // Array to store converted quantities
        static void Main(string[] args)
        {
            // Creating an instance of the main class
            Program program = new Program();
            // Setting console window properties
            Console.Title = "Recipe Manager";
            Console.ForegroundColor = ConsoleColor.White;
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.Clear();
            // Displaying welcome message
            Console.WriteLine("HI , Welcome to Recipe Manager!");
            Console.WriteLine("******************************************************");
            // Calling the recipe method
            program.Recipe();
        }

        // Method for managing recipes
        public void Recipe()
        {
            while (true)
            {
                // Prompting user to input the number of recipes
                Console.Write("\nEnter the number of recipes: ");
                // Reading user input
                NumberOfRecipes = int.Parse(Console.ReadLine());
                // Checking condition for number of recipes
                if (NumberOfRecipes == NumberOfRecipes)
                {
                    // Looping to input recipe names
                    for (int i = 0; i < NumberOfRecipes; i++)
                    {
                        // Prompting user to input recipe name
                        Console.Write("Enter the name of the recipe: ");
                        // Enqueueing recipe name into the queue
                        RecipeNames.Enqueue(Console.ReadLine().ToUpper());
                    }
                    // Storing recipe names in a list
                    List<string> recipeList = new List<string>(RecipeNames);
                    // Sorting the list alphabetically
                    recipeList.Sort();
                    // Displaying sorted recipe names
                    Console.WriteLine("\nRecipes:");
                    foreach (string recipeName in recipeList)
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine(" - " + recipeName);
                    }
                    Console.ForegroundColor = ConsoleColor.White;
                    // Prompting user to choose a recipe
                    Console.Write("\nWould you like to choose any of the recipes listed? (Yes/No): ");
                    // Reading user input
                    Option = (Console.ReadLine().ToUpper());
                    if (Option == "YES")
                    {
                        Console.Write("Enter the recipe name: ");
                        IndexFromList = (Console.ReadLine().ToUpper());
                        if (recipeList.Contains(IndexFromList))
                        {
                            Console.Write("Would you like to enter the ingredients for " + IndexFromList + "? (Yes/No): ");
                            Option2 = (Console.ReadLine().ToUpper());
                            if (Option2 == "YES")
                            {
                                // Calling the method to input ingredients
                                Ingredient();
                                break;
                            }
                            else
                            {
                                Console.WriteLine("Back to the menu!");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Recipe not found!");
                            break;
                        }
                    }
                    else
                    {
                        Console.Write("Would you like to close the application? (Yes/No): ");
                        string response = Console.ReadLine().ToUpper();
                        if (response == "YES")
                        {
                            break;
                        }
                    }
                }
            }
        }

        // Method for managing ingredients
        public void Ingredient()
        {
            while (true)
            {
                // Prompting user to input the number of ingredients
                Console.Write("\nEnter the number of ingredients: ");
                // Reading user input
                NumberOfIngredientsInput = (int.Parse(Console.ReadLine()));
                if (NumberOfIngredientsInput == NumberOfIngredientsInput)
                {
                    for (int num = 0; num < NumberOfIngredientsInput; num++)
                    {
                        Console.WriteLine("\nIngredient #" + (num + 1) + ":");
                        // Prompting user to input ingredient details
                        Console.Write("Name: ");
                        IngredientNames.Enqueue(Console.ReadLine());
                        Console.Write("Quantity: ");
                        ConvertedQuantitiesY[num] = float.Parse(Console.ReadLine());
                        Console.Write("Measurement Unit (Teaspoon): ");
                        MeasurementUnits.Enqueue(float.Parse(Console.ReadLine()));
                        Console.Write("Calories: ");
                        CalorieCount = int.Parse(Console.ReadLine());
                        if (CalorieCount > 300)
                        {
                            ContainCalories.Enqueue(CalorieCount);
                        }
                        else
                        {
                            ContainCalories.Enqueue(CalorieCount);
                        }
                        Console.Write("Food Group: ");
                        FoodGroupsInput.Enqueue(Console.ReadLine());
                        Console.Write("Number of Steps: ");
                        Steps.Enqueue(int.Parse(Console.ReadLine()));
                        Console.Write("Description of Steps: ");
                        Descriptions.Enqueue(Console.ReadLine());
                    }
                    // Displaying ingredient details
                    Console.WriteLine("\nIngredients:");
                    string[] ConvertedIngredientNames = IngredientNames.ToArray();
                    ConvertedQuantities = Quantities.ToArray();
                    float[] ConvertedUnits = MeasurementUnits.ToArray();
                    ConvertedDescriptions = Descriptions.ToArray();
                    ConvertedSteps = Steps.ToArray();
                    FoodGroups = FoodGroupsInput.ToArray();
                    CaloriesPerIngredient = ContainCalories.ToArray();
                    for (int b = 0; b < NumberOfIngredientsInput; b++)
                    {
                        Console.WriteLine("\n- " + ConvertedIngredientNames[b]);
                        Console.WriteLine("  Quantity: " + ConvertedQuantitiesY[b]);
                        Console.WriteLine("  Teaspoons: " + ConvertedUnits[b] / 5);
                        Console.WriteLine("  Calories: " + CaloriesPerIngredient[b]);
                        Console.WriteLine("  Food Group: " + FoodGroups[b]);
                        Console.WriteLine("  Steps: ");
                        Console.WriteLine("    Step " + ConvertedSteps[b] + ": " + ConvertedDescriptions[b]);
                    }
                    // Calculating and displaying total calories
                    CalorieCalculationDelegate calorieDelegate = CalculateTotalCalories;
                    calorieDelegate.Invoke(CaloriesPerIngredient);
                    Console.WriteLine("\nWould you like to clear all data? (Yes/No): ");
                    Condition2 = Console.ReadLine().ToUpper();
                    if (Condition2 == "YES")
                    {
                        ClearData();
                        break;
                    }
                    else
                    {
                        Console.WriteLine("\nWould you like to exit the application? (Yes/No): ");
                        Condition3 = Console.ReadLine().ToUpper();
                        if (Condition3 == "YES")
                        {
                            break;
                        }
                        else
                        {
                            Recipe();
                        }
                        break;
                    }
                }
            }
        }

        // Method for calculating total calories
        public void CalculateTotalCalories(int[] calorieArray)
        {
            int sum = 0;
            for (int num = 0; num < NumberOfIngredientsInput; num++)
            {
                sum += calorieArray[num];
            }
            Console.WriteLine("\nTotal Calories: " + sum);
            if (sum > 300)
            {
                Console.WriteLine("Total calories exceeded 300");
            }
        }

        // Method to clear all data
        public void ClearData()
        {
            // Resetting all queues and arrays
            IngredientNames.Clear();
            Descriptions.Clear();
            Quantities.Clear();
            MeasurementUnits.Clear();
            Steps.Clear();
            RecipeNames.Clear();
            NumberOfIngredients.Clear();
            ContainCalories.Clear();
            FoodGroupsInput.Clear();
            Array.Clear(CaloriesPerIngredient, 0, CaloriesPerIngredient.Length);
            Array.Clear(FoodGroups, 0, FoodGroups.Length);
            Array.Clear(ConvertedSteps, 0, ConvertedSteps.Length);
            Array.Clear(ConvertedQuantities, 0, ConvertedQuantities.Length);
            Array.Clear(ConvertedQuantities1, 0, ConvertedQuantities1.Length);
            Array.Clear(ConvertedDescriptions, 0, ConvertedDescriptions.Length);
            Array.Clear(ConvertedQuantitiesY, 0, ConvertedQuantitiesY.Length);
            // Displaying confirmation message
            Console.WriteLine("\nAll data have been successfully deleted!");
            // Clearing the screen
            Console.Clear();

            // Returning to main menu
            Recipe();
        }
    }
}
